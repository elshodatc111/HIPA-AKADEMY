<?php $__env->startSection('title','Yangi guruh'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Yangi guruh</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('AdminGuruh')); ?>">Guruhlar</a></li>
            <li class="breadcrumb-item active">Yangi guruh</li>
        </ol>
    </nav>
</div>

<section class="section dashboard">
    <div class="card info-card sales-card">
        <div class="card-body text-center pt-3">
            <ul class="nav nav-tabs d-flex">
                <li class="nav-item flex-fill">
                    <a class="nav-link w-100" href="<?php echo e(route('AdminGuruh')); ?>">Guruhlar</a>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                    <a class="nav-link w-100" href="<?php echo e(route('AdminGuruhEnd')); ?>">Yakunlangan guruhlar</a>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                    <a class="nav-link w-100 active bg-success text-white" href="<?php echo e(route('AdminGuruhCreate')); ?>">Yangi guruh</a>
                </li>
            </ul>
            <div class="w-100 mt-2">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php elseif(Session::has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                <?php endif; ?>
                <form action="<?php echo e(route('AdminGuruhCreate1')); ?>" method="post" id="form1">
                    <?php echo csrf_field(); ?> 
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="guruh_name" style="text-align:left;width:100%">Guruh nomi</label>
                            <input type="text" name="guruh_name" value="<?php echo e(old('guruh_name')); ?>" class="form-control" required>
                            <label for="guruh_price" style="text-align:left;width:100%" class="mt-2">Guruh narxi</label>
                            <select name="guruh_price" class="form-select" required>
                                <option value="">Tanlang</option>
                                <?php $__currentLoopData = $TulovSetting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><b>Summa: </b><?php echo e($item->tulov_summa); ?><b> Chegirma: </b><?php echo e($item->chegirma); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="row">
                                <div class="col-lg-6">
                                    <label for="guruh_start" class="mt-2" style="text-align:left;width:100%" class="mt-2">Dars boshlanish vaqti</label>
                                    <input type="date" name="guruh_start" value="<?php echo e(old('guruh_start')); ?>" class="form-control" required>
                                </div>
                                <div class="col-lg-6">
                                    <label for="hafta_kun" class="mt-2" style="text-align:left;width:100%" class="mt-2">Hafta kunlari</label>
                                    <select name="hafta_kun" class="form-select" required>
                                        <option value="">Tanlang</option>
                                        <option value="juft">Juft kunlar</option>
                                        <option value="toq">Toq kunlar</option>
                                        <option value="xarkuni">Xar kuni</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <div class="col-lg-6">
                                    <label for="" class="mt-2" style="text-align:left;width:100%">Dars xonasi</label>
                                    <select name="room_id" class="form-select" required>
                                        <option value="">Tanlang</option>
                                        <?php $__currentLoopData = $Room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->room_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-lg-6">
                                    <label for="cours_id" class="mt-2" style="text-align:left;width:100%">Guruh uchun kurs</label>
                                    <select name="cours_id" class="form-select" required>
                                        <option value="">Tanlang</option>
                                        <?php $__currentLoopData = $Cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->cours_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <label for="techer_id" style="text-align:left;width:100%" class="mt-2">Guruh o'qituvchisi</label>
                            <select name="techer_id" class="form-select" required>
                                <option value="">Tanlang</option>
                                <?php $__currentLoopData = $Techer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="row">
                                <div class="col-lg-6">
                                    <label for="techer_price"  class="pt-2">O'qituvchiga to'lov</label>
                                    <input type="text" name="techer_price" class="form-control" id="summa1" required>
                                </div>
                                <div class="col-lg-6">
                                    <label for="techer_bonus" class="pt-2">O'qituvchiga bonus</label>
                                    <input type="text" name="techer_bonus" class="form-control" id="summa2" required>
                                </div>
                            </div>
                            
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary w-50 mt-2">Davom etish</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u929278937/domains/atko.tech/public_html/Alfraganus/resources/views/Admin/guruh/create.blade.php ENDPATH**/ ?>