<?php $__env->startSection('title','Yangi guruh'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Yangi guruh</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('AdminGuruh')); ?>">Guruhlar</a></li>
            <li class="breadcrumb-item active">Yangi guruh</li>
        </ol>
    </nav>
</div>

<section class="section dashboard">
    <div class="card info-card sales-card">
        <div class="card-body text-center pt-3">
            <ul class="nav nav-tabs d-flex">
                <li class="nav-item flex-fill">
                    <a class="nav-link w-100" href="<?php echo e(route('AdminGuruh')); ?>">Guruhlar</a>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                    <a class="nav-link w-100" href="<?php echo e(route('AdminGuruhEnd')); ?>">Yakunlangan guruhlar</a>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                    <a class="nav-link w-100 active bg-primary text-white" href="<?php echo e(route('AdminGuruhCreate')); ?>">Yangi guruh</a>
                </li>
            </ul>
            <div class="w-100 mt-2">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php elseif(Session::has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                <?php endif; ?>
                <h5 class="card-title w-100 text-center mb-0 pb-1">Yangi guruh haqida</h5>
                <div class="row">
                    <div class="col-lg-6">
                        <table class="table table-bordered" style="font-size:14px;">
                            <tr>
                                <th style="text-align:left">Guruh:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['guruh_name']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Guruh narxi:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['guruh_price']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">O'qituvchi:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['guruh_techer']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">O'qituvchiga to'lov:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['techer_price']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">O'qituvchiga bonus:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['techer_bonus']); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-lg-6">
                        <table class="table table-bordered" style="font-size:14px;">
                            <tr>
                                <th style="text-align:left">Kurs:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['cours']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Dars xonasi:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['room']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Hafta Kunlari:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['hafta_kun']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Boshlanish vaqti:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['guruh_start']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Tugash vaqti:</th>
                                <td style="text-align:right"><?php echo e($GuruhView['guruh_end']); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-lg-8">
                        <h5 class="card-title w-100 text-center my-1 py-1">Dars kunlari</h5>
                        <?php if($GuruhView['count_day']==13): ?>
                        <table class="table table-bordered" style="font-size:14px;">
                            <tr>
                                <td><b>1-dars:</b> <?php echo e($GuruhView['kunlar'][0]); ?></td>
                                <td><b>5-dars:</b> <?php echo e($GuruhView['kunlar'][4]); ?></td>
                                <td><b>9-dars:</b> <?php echo e($GuruhView['kunlar'][8]); ?></td>
                            </tr>
                            <tr>
                                <td><b>2-dars:</b> <?php echo e($GuruhView['kunlar'][1]); ?></td>
                                <td><b>6-dars:</b> <?php echo e($GuruhView['kunlar'][5]); ?></td>
                                <td><b>10-dars:</b> <?php echo e($GuruhView['kunlar'][9]); ?></td>
                            </tr>
                            <tr>
                                <td><b>3-dars:</b> <?php echo e($GuruhView['kunlar'][2]); ?></td>
                                <td><b>7-dars:</b> <?php echo e($GuruhView['kunlar'][6]); ?></td>
                                <td><b>11-dars:</b> <?php echo e($GuruhView['kunlar'][10]); ?></td>
                            </tr>
                            <tr>
                                <td><b>4-dars:</b> <?php echo e($GuruhView['kunlar'][3]); ?></td>
                                <td><b>8-dars:</b> <?php echo e($GuruhView['kunlar'][7]); ?></td>
                                <td><b>12-dars:</b> <?php echo e($GuruhView['kunlar'][11]); ?></td>
                            </tr>
                            <tr>
                                <td colspan=3 class="text-center"><b>Qo'shimcha dars:</b> <?php echo e($GuruhView['kunlar'][12]); ?></td>
                            </tr>
                        </table>
                        <?php else: ?>
                        <table class="table table-bordered" style="font-size:14px;">
                            <tr>
                                <td><b>1-dars:</b> <?php echo e($GuruhView['kunlar'][0]); ?></td>
                                <td><b>9-dars:</b> <?php echo e($GuruhView['kunlar'][8]); ?></td>
                                <td><b>17-dars:</b> <?php echo e($GuruhView['kunlar'][16]); ?></td>
                            </tr>
                            <tr>
                                <td><b>2-dars:</b> <?php echo e($GuruhView['kunlar'][1]); ?></td>
                                <td><b>10-dars:</b> <?php echo e($GuruhView['kunlar'][9]); ?></td>
                                <td><b>18-dars:</b> <?php echo e($GuruhView['kunlar'][17]); ?></td>
                            </tr>
                            <tr>
                                <td><b>3-dars:</b> <?php echo e($GuruhView['kunlar'][2]); ?></td>
                                <td><b>11-dars:</b> <?php echo e($GuruhView['kunlar'][10]); ?></td>
                                <td><b>19-dars:</b> <?php echo e($GuruhView['kunlar'][18]); ?></td>
                            </tr>
                            <tr>
                                <td><b>4-dars:</b> <?php echo e($GuruhView['kunlar'][3]); ?></td>
                                <td><b>12-dars:</b> <?php echo e($GuruhView['kunlar'][11]); ?></td>
                                <td><b>20-dars:</b> <?php echo e($GuruhView['kunlar'][19]); ?></td>
                            </tr>
                            <tr>
                                <td><b>5-dars:</b> <?php echo e($GuruhView['kunlar'][4]); ?></td>
                                <td><b>13-dars:</b> <?php echo e($GuruhView['kunlar'][12]); ?></td>
                                <td><b>21-dars:</b> <?php echo e($GuruhView['kunlar'][20]); ?></td>
                            </tr>
                            <tr>
                                <td><b>6-dars:</b> <?php echo e($GuruhView['kunlar'][5]); ?></td>
                                <td><b>14-dars:</b> <?php echo e($GuruhView['kunlar'][13]); ?></td>
                                <td><b>22-dars:</b> <?php echo e($GuruhView['kunlar'][21]); ?></td>
                            </tr>
                            <tr>
                                <td><b>7-dars:</b> <?php echo e($GuruhView['kunlar'][6]); ?></td>
                                <td><b>15-dars:</b> <?php echo e($GuruhView['kunlar'][14]); ?></td>
                                <td><b>23-dars:</b> <?php echo e($GuruhView['kunlar'][22]); ?></td>
                            </tr>
                            <tr>
                                <td><b>8-dars:</b> <?php echo e($GuruhView['kunlar'][7]); ?></td>
                                <td><b>16-dars:</b> <?php echo e($GuruhView['kunlar'][15]); ?></td>
                                <td><b>24-dars:</b> <?php echo e($GuruhView['kunlar'][23]); ?></td>
                            </tr>
                        </table>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-4">
                        <h5 class="card-title text-center my-1 py-1 w-100">Dars vaqtini tanlang</h5>
                        <form action="<?php echo e(route('AdminGuruhCreate2')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="filial_id" value="<?php echo e($GuruhInput['filial_id']); ?>">
                            <input type="hidden" name="techer_id" value="<?php echo e($GuruhInput['techer_id']); ?>">
                            <input type="hidden" name="cours_id" value="<?php echo e($GuruhInput['cours_id']); ?>">
                            <input type="hidden" name="room_id" value="<?php echo e($GuruhInput['room_id']); ?>">
                            <input type="hidden" name="count_day" value="<?php echo e($GuruhView['count_day']); ?>">
                            <input type="hidden" name="guruh_name" value="<?php echo e($GuruhInput['guruh_name']); ?>">
                            <input type="hidden" name="guruh_price" value="<?php echo e($GuruhInput['guruh_price']); ?>">
                            <input type="hidden" name="guruh_chegirma" value="<?php echo e($GuruhInput['guruh_chegirma']); ?>">
                            <input type="hidden" name="guruh_admin_chegirma" value="<?php echo e($GuruhInput['guruh_admin_chegirma']); ?>">
                            <input type="hidden" name="techer_price" value="<?php echo e($GuruhInput['techer_price']); ?>">
                            <input type="hidden" name="techer_bonus" value="<?php echo e($GuruhInput['techer_bonus']); ?>">
                            <input type="hidden" name="guruh_status" value="<?php echo e($GuruhInput['guruh_status']); ?>">
                            <input type="hidden" name="guruh_start" value="<?php echo e($GuruhInput['guruh_start']); ?>">
                            <input type="hidden" name="guruh_end" value="<?php echo e($GuruhInput['guruh_end']); ?>">
                            <?php $__currentLoopData = $GuruhView['kunlar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="date<?php echo e($key); ?>" value="<?php echo e($item); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <script>
                                function button(){
                                    document.getElementById("buttons").style.display = "none"
                                }
                            </script>
                            <select name="guruh_vaqt" class="form-select" required>
                                <option value="">Tanlang...</option>
                                <?php $__currentLoopData = $GuruhView['dars_vaqtlari']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item['id']); ?>"><?php echo e($item['text']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="btn btn-success w-100 mt-2" id="buttons" onclick="button()">Guruhni Saqlash</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u929278937/domains/atko.tech/public_html/Alfraganus/resources/views/Admin/guruh/create2.blade.php ENDPATH**/ ?>