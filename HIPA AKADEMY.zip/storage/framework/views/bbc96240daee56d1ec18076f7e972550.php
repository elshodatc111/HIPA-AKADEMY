<?php $__env->startSection('title','Yangi guruh'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Yangi guruh</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('AdminGuruh')); ?>">Guruhlar</a></li>
            <li class="breadcrumb-item active">Yangi guruh</li>
        </ol>
    </nav>
</div>

<section class="section dashboard">
    <div class="card info-card sales-card">
        <div class="card-body text-center pt-3">
            <div class="w-100">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php elseif(Session::has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                <?php endif; ?>
                <h5 class="card-title w-100 text-center mb-0 pb-1"><?php echo e($Guruh->guruh_name); ?> guruhning davomi</h5>
                <div class="row">
                    <div class="col-lg-6">
                        <table class="table table-bordered" style="font-size:14px;">
                            <tr>
                                <th style="text-align:left">Yangi guruh:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['guruh_name']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Guruh narxi:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['guruh_price']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">O'qituvchi:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['techer_id']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">O'qituvchiga to'lov:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['techer_price']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">O'qituvchiga bonus:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['techer_bonus']); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-lg-6">
                        <table class="table table-bordered" style="font-size:14px;">
                            <tr>
                                <th style="text-align:left">Kurs:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['cours_id']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Dars xonasi:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['room_id']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Hafta Kunlari:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['hafta_kuni']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Boshlanish vaqti:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['guruh_start']); ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:left">Tugash vaqti:</th>
                                <td style="text-align:right"><?php echo e($NewGuruh['guruh_end']); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-lg-8">
                        <h5 class="card-title w-100 text-center my-1 py-1">Dars kunlari</h5>
                        <?php if($NewGuruh['count_kun']==13): ?>
                        <table class="table table-bordered" style="font-size:14px;">
                            <tr>
                                <td><b>1-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][0]); ?></td>
                                <td><b>7-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][6]); ?></td>
                            </tr>
                            <tr>
                                <td><b>2-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][1]); ?></td>
                                <td><b>8-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][7]); ?></td>
                            </tr>
                            <tr>
                                <td><b>3-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][2]); ?></td>
                                <td><b>9-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][8]); ?></td>
                            </tr>
                            <tr>
                                <td><b>4-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][3]); ?></td>
                                <td><b>10-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][9]); ?></td>
                            </tr>
                            <tr>
                                <td><b>5-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][4]); ?></td>
                                <td><b>11-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][10]); ?></td>
                            </tr>
                            <tr>
                                <td><b>6-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][5]); ?></td>
                                <td><b>12-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][11]); ?></td>
                            </tr>
                            <tr>
                                <td colspan=2 class="text-center"><b>Qo'shimcha dars:</b> <?php echo e($NewGuruh['dars_kunlari'][12]); ?></td>
                            </tr>
                        </table>
                        <?php else: ?>
                        <table class="table table-bordered" style="font-size:14px;">
                            <tr>
                                <td><b>1-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][0]); ?></td>
                                <td><b>9-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][8]); ?></td>
                                <td><b>17-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][16]); ?></td>
                            </tr>
                            <tr>
                                <td><b>2-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][1]); ?></td>
                                <td><b>10-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][9]); ?></td>
                                <td><b>18-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][17]); ?></td>
                            </tr>
                            <tr>
                                <td><b>3-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][2]); ?></td>
                                <td><b>11-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][10]); ?></td>
                                <td><b>19-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][18]); ?></td>
                            </tr>
                            <tr>
                                <td><b>4-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][3]); ?></td>
                                <td><b>12-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][11]); ?></td>
                                <td><b>20-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][19]); ?></td>
                            </tr>
                            <tr>
                                <td><b>5-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][4]); ?></td>
                                <td><b>13-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][12]); ?></td>
                                <td><b>21-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][20]); ?></td>
                            </tr>
                            <tr>
                                <td><b>6-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][5]); ?></td>
                                <td><b>14-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][13]); ?></td>
                                <td><b>22-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][21]); ?></td>
                            </tr>
                            <tr>
                                <td><b>7-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][6]); ?></td>
                                <td><b>15-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][14]); ?></td>
                                <td><b>23-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][22]); ?></td>
                            </tr>
                            <tr>
                                <td><b>8-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][7]); ?></td>
                                <td><b>16-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][15]); ?></td>
                                <td><b>24-dars:</b> <?php echo e($NewGuruh['dars_kunlari'][23]); ?></td>
                            </tr>
                        </table>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-4">
                        <h5 class="card-title w-100 text-center my-1 py-1">Yangi guruhga talaba o'tqazish</h5>
                        <form action="<?php echo e(route('CreateGuruhNext2')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <table class="table table-bordered" style="font-size:14px;">
                                <?php $__currentLoopData = $NewGuruh['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="form-check form-switch mt-1" style="text-align:left;">
                                            <input class="form-check-input" type="checkbox" name="User<?php echo e($item['id']); ?>" id="User<?php echo e($item['id']); ?>">
                                            <label class="form-check-label w-100" for="User<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></label>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <input type="hidden" name="count_kun" value=<?php echo e($NewGuruh['count_kun']); ?>>
                            <input type="hidden" name="techer_id" value="<?php echo e($NewGuruhForm['techer_id']); ?>">
                            <input type="hidden" name="cours_id" value="<?php echo e($NewGuruhForm['cours_id']); ?>">
                            <input type="hidden" name="room_id" value="<?php echo e($NewGuruhForm['room_id']); ?>">
                            <input type="hidden" name="guruh_name" value="<?php echo e($NewGuruhForm['guruh_name']); ?>">
                            <input type="hidden" name="guruh_price" value="<?php echo e($NewGuruhForm['guruh_price']); ?>">
                            <input type="hidden" name="guruh_chegirma" value="<?php echo e($NewGuruhForm['guruh_chegirma']); ?>">
                            <input type="hidden" name="guruh_admin_chegirma" value="<?php echo e($NewGuruhForm['guruh_admin_chegirma']); ?>">
                            <input type="hidden" name="techer_price" value="<?php echo e($NewGuruhForm['techer_price']); ?>">
                            <input type="hidden" name="techer_bonus" value="<?php echo e($NewGuruhForm['techer_bonus']); ?>">
                            <input type="hidden" name="guruh_status" value="<?php echo e($NewGuruhForm['guruh_status']); ?>">
                            <input type="hidden" name="guruh_start" value="<?php echo e($NewGuruhForm['guruh_start']); ?>">
                            <input type="hidden" name="guruh_end" value="<?php echo e($NewGuruh['guruh_end']); ?>">
                            <input type="hidden" name="guruh_id" value="<?php echo e($Guruh['id']); ?>">
                            <?php $__currentLoopData = $NewGuruh['dars_kunlari']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="kun<?php echo e($key); ?>" value="<?php echo e($item); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <label for="">Dars vaqtini tanlang</label>
                            <select name="guruh_vaqt" class="form-select">
                                <option value="">Tanlang</option>
                                <?php $__currentLoopData = $NewGuruh['bosh_vaqtlar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item['id']); ?>"><?php echo e($item['text']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <script>
                                function button(){
                                    document.getElementById("buttons").style.display = "none"
                                }
                            </script>
                            <button class="btn btn-primary w-100 mt-2" onclick="button()">Yangi guruhni saqlash</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views/Admin/guruh/create_next.blade.php ENDPATH**/ ?>