<?php $__env->startSection('title','Moliya'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Moliya</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Moliya</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<section class="section dashboard row mb-0 pb-0">
    <div class="col-lg-3">
        <div class="card mb-2">
            <div class="card-body text-center" style="min-height:175px;">
                <h5 class="card-title mb-0 pb-2"><i class="bi bi-bag-check"></i> Kassada mavjud to'lovlar</h5>
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <b class="card-title p-0 m-0" style="font-size:14px;"><i class="bi bi-cash"></i> Naqt:</b>
                        <span class="badge bg-success rounded-pill"><?php echo e($Kassa['Naqt']); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <b class="card-title p-0 m-0" style="font-size:14px;"><i class="bi bi-credit-card-2-back"></i> Plastik:</b>
                        <span class="badge bg-success rounded-pill"><?php echo e($Kassa['Plastik']); ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card mb-2">
            <div class="card-body text-center" style="min-height:175px;">
                <h5 class="card-title mb-0 pb-2"><i class="bi bi-capslock"></i> Chiqim kutilmoqda</h5>
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <b class="card-title p-0 m-0" style="font-size:14px;"><i class="bi bi-cash"></i> Naqt:</b>
                        <span class="badge bg-warning rounded-pill"><?php echo e($Kassa['ChiqimNaqt']); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <b class="card-title p-0 m-0" style="font-size:14px;"><i class="bi bi-credit-card-2-back"></i> Plastik:</b>
                        <span class="badge bg-warning rounded-pill"><?php echo e($Kassa['ChiqimPlastik']); ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card mb-2">
            <div class="card-body text-center" style="min-height:175px;">
                <div class="table-responsive">
                    <h5 class="card-title m-0 pb-2"><i class="bi bi-cart4"></i> Xarajat kutilmoqda</h5>
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <b class="card-title p-0 m-0" style="font-size:14px;"><i class="bi bi-cash"></i> Naqt:</b>
                            <span class="badge bg-info rounded-pill"><?php echo e($Kassa['XarajatNaqt']); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <b class="card-title p-0 m-0" style="font-size:14px;"><i class="bi bi-credit-card-2-back"></i> Plastik:</b>
                            <span class="badge bg-info rounded-pill"><?php echo e($Kassa['XarajatPlastik']); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card mb-2">
            <div class="card-body text-center" style="min-height:175px;">
                <div class="table-responsive">
                    <h5 class="card-title m-0 pb-2"><i class="bi bi-bag-check"></i> Ish haqi to'lovi uchun</h5>
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <b class="card-title p-0 m-0" style="font-size:14px;"><i class="bi bi-cash"></i> Naqt:</b>
                            <span class="badge bg-primary rounded-pill"><?php echo e($IshHaq['naqt']); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <b class="card-title p-0 m-0" style="font-size:14px;"><i class="bi bi-credit-card-2-back"></i> Plastik:</b>
                            <span class="badge bg-primary rounded-pill"><?php echo e($IshHaq['plastik']); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="row text-center pb-3 mt-0 pt-0">
    <div class="col-lg-4 mt-2 mt-lg-0">
        <button class="btn btn-danger text-white w-100 mt-2" 
        data-bs-toggle="modal" data-bs-target="#QaytarilganTulov">
        <i class="bi bi-capslock"></i> Qaytarildi: <?php echo e($QaytarildiSumma); ?></button>
    </div>
    <div class="col-lg-4 mt-2 mt-lg-0">
        <button class="btn btn-warning text-white w-100 mt-2" 
        data-bs-toggle="modal" data-bs-target="#KassadanChiqim">
        <i class="bi bi-capslock"></i> Kassadan chiqim</button>
    </div>
    <div class="col-lg-4 mt-2 mt-lg-0">
        <button class="btn btn-info text-white w-100 mt-2" 
        data-bs-toggle="modal" data-bs-target="#XarajatChiqim">
        <i class="bi bi-cart4"></i> Xarajat uchun chiqim</button>
    </div>
</div>
<div class="modal fade" id="QaytarilganTulov" tabindex="-1">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="card-title p-0 m-0 w-100 text-center"><i class="bi bi-capslock"></i> Qaytarilgan to'lovlar (Oxirgi 7 kun)</h5>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-center" style="font-size:14px">
                        <thead>
                            <th class="bg-primary text-white">#</th>
                            <th class="bg-primary text-white">Talaba</th>
                            <th class="bg-primary text-white">Summa</th>
                            <th class="bg-primary text-white">Qaytarish haqida</th>
                            <th class="bg-primary text-white">Tulov turi</th>
                            <th class="bg-primary text-white">Qaytarish vaqti</th>
                            <th class="bg-primary text-white">Meneger</th>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $Qaytarildi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><a href="<?php echo e(route('StudentShow',$item['user_id'])); ?>"><?php echo e($item['user']); ?></a></td>
                                <td><?php echo e($item['summa']); ?></td>
                                <td><?php echo e($item['about']); ?></td>
                                <td><?php echo e($item['type']); ?></td>
                                <td><?php echo e($item['created_at']); ?></td>
                                <td><?php echo e($item['admin']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=8 class="text-center">Qaytarilgan to'lovlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="KassadanChiqim" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="card-title p-0 m-0 w-100 text-center"><i class="bi bi-capslock"></i> Kassadan chiqim</h5>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('AdminMoliyaCHiqim')); ?>" method="post" id="form1">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="xodisa" value="Chiqim">
                    <input type="hidden" name="status" value="false">
                    <input type="hidden" name="naqt" value="<?php echo e($Kassa['Naqt']); ?>">
                    <input type="hidden" name="plastik" value="<?php echo e($Kassa['Plastik']); ?>">
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="summa" class="mb-1">Chiqim summasi</label>
                            <input type="text" name="summa" id="summa1" class="form-control" required>
                        </div>
                        <div class="col-lg-6">
                            <label for="type" class="mb-1 mt-2 mt-lg-0">Chiqim turi</label>
                            <select name="type" class="form-select" required>
                                <option value="">Tanlang</option>
                                <option value="Naqt">Naqt</option>
                                <option value="Plastik">Plastik</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label for="about" class="mt-3 mb-1">Chiqim haqida</label>
                            <textarea name="about" class="form-control" required></textarea>
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn btn-secondary mt-3 w-100" data-bs-dismiss="modal">Bekor qilish</button>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary mt-3 w-100">Chiqim</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="XarajatChiqim" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="card-title p-0 m-0 w-100 text-center"><i class="bi bi-cart4"></i> Xarajat uchun chiqim</h5>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('AdminMoliyaXarajat')); ?>" method="post" id="form2">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="xodisa" value="Xarajat">
                    <input type="hidden" name="status" value="false">
                    <input type="hidden" name="naqt" value="<?php echo e($Kassa['Naqt']); ?>">
                    <input type="hidden" name="plastik" value="<?php echo e($Kassa['Plastik']); ?>">
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="summa" class="mb-1">Xarajat summasi</label>
                            <input type="text" name="summa" id="summa2" class="form-control" required>
                        </div>
                        <div class="col-lg-6">
                            <label for="type" class="mb-1 mt-2 mt-lg-0">Xarajat turi</label>
                            <select name="type" class="form-select" required>
                                <option value="">Tanlang</option>
                                <option value="Naqt">Naqt</option>
                                <option value="Plastik">Plastik</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label for="about" class="mt-3 mb-1">Xarajat haqida</label>
                            <textarea name="about" class="form-control" required></textarea>
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn btn-secondary mt-3 w-100" data-bs-dismiss="modal">Bekor qilish</button>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary mt-3 w-100">Xarajat</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body pt-3">
        <ul class="nav nav-tabs nav-tabs-bordered d-flex" id="borderedTabJustified" role="tablist">
            <li class="nav-item flex-fill" role="presentation">
                <button class="nav-link w-100 active" id="home-tab" 
                data-bs-toggle="tab" data-bs-target="#bordered-justified-home" type="button" 
                role="tab" aria-controls="home" aria-selected="true"><i class="bi bi-capslock"></i> Tasdiqlanmagan chiqimlar</button>
            </li>
            <li class="nav-item flex-fill" role="presentation">
                <button class="nav-link w-100" id="profile-tab" 
                data-bs-toggle="tab" data-bs-target="#bordered-justified-profile" type="button" 
                role="tab" aria-controls="profile" aria-selected="false"><i class="bi bi-cart4"></i> Tasdiqlanmagan xarajatlar</button>
            </li>
        </ul>
        <div class="tab-content pt-2" id="borderedTabJustifiedContent">
            <div class="tab-pane fade show active" id="bordered-justified-home" role="tabpanel" aria-labelledby="home-tab">
                <div class="table-responsive pt-3">
                    <table class="table text-center table-bordered table-hover" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th class="text-center bg-primary text-white">#</th>
                                <th class="text-center bg-primary text-white">Summa</th>
                                <th class="text-center bg-primary text-white">Chiqim turi</th>
                                <th class="text-center bg-primary text-white">Chiqim haqida</th>
                                <th class="text-center bg-primary text-white">Chiqim vaqti</th>
                                <th class="text-center bg-primary text-white">Meneger</th>
                                <th class="text-center bg-primary text-white">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $Chiqim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($item['summa']); ?></td>
                                <td><?php echo e($item['type']); ?></td>
                                <td><?php echo e($item['about']); ?></td>
                                <td><?php echo e($item['created_at']); ?></td>
                                <td><?php echo e($item['user']); ?></td>
                                <td>
                                    <form action="<?php echo e(route('AdminMoliyaCHiqimDelete')); ?>" method="post" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                        <button type="submit" class="btn btn-danger px-1 py-0"><i class="bi bi-trash"></i></button>
                                    </form>
                                    <?php if(Auth::user()->type=='SuperAdmin'): ?>
                                    <form action="<?php echo e(route('AdminMoliyaCHiqimTasdiq')); ?>" method="post" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                        <button type="submit" class="btn btn-success px-1 py-0"><i class="bi bi-check"></i></button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=7 class="text-center"> Tasdiqlanmagan chiqimlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="bordered-justified-profile" role="tabpanel" aria-labelledby="profile-tab">
                <div class="table-responsive pt-3">
                    <table class="table text-center table-bordered table-hover" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th class="text-center bg-primary text-white">#</th>
                                <th class="text-center bg-primary text-white">Summa</th>
                                <th class="text-center bg-primary text-white">Xarajat turi</th>
                                <th class="text-center bg-primary text-white">Xarajat haqida</th>
                                <th class="text-center bg-primary text-white">Xarajat vaqti</th>
                                <th class="text-center bg-primary text-white">Meneger</th>
                                <th class="text-center bg-primary text-white">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $Xarajat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($item['summa']); ?></td>
                                <td><?php echo e($item['type']); ?></td>
                                <td><?php echo e($item['about']); ?></td>
                                <td><?php echo e($item['created_at']); ?></td>
                                <td><?php echo e($item['user']); ?></td>
                                <td>
                                    <form action="<?php echo e(route('AdminMoliyaXarajatDelete')); ?>" method="post" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                        <button type="submit" class="btn btn-danger px-1 py-0"><i class="bi bi-trash"></i></button>
                                    </form>
                                    <?php if(Auth::user()->type=='SuperAdmin'): ?>
                                    <form action="<?php echo e(route('AdminMoliyaXarajatTasdiq')); ?>" method="post" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                        <button type="submit" class="btn btn-success px-1 py-0"><i class="bi bi-check"></i></button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=7 class="text-center"> Tasdiqlanmagan xarajatlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if(Auth::user()->type=='SuperAdmin'): ?>
<div class="card">
    <div class="card-body">
        <h5 class="card-title w-100 text-center">O'chirilgan to'lovlar(Oxirgi 7 kunlik)</h5>
        <div class="table-responsive">
            <table class="table table-bordered text-center" style="font-size:12px;">
                <tr>
                    <th class="bg-primary text-white">#</th>
                    <th class="bg-primary text-white">Talaba</th>
                    <th class="bg-primary text-white">Summa</th>
                    <th class="bg-primary text-white">Type</th>
                    <th class="bg-primary text-white">O'chirilgan vaqt</th>
                    <th class="bg-primary text-white">Meneger</th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $TulDel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td style="text-align:left"><a href="<?php echo e(route('StudentShow',$item['user_id'])); ?>"><?php echo e($item['student']); ?></a></td>
                        <td><?php echo e($item['summa']); ?></td>
                        <td><?php echo e($item['type']); ?></td>
                        <td><?php echo e($item['created_at']); ?></td>
                        <td><?php echo e($item['admin']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan=6 class="text-center">O'chirilgan to'lovlar mavjud emas.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u929278937/domains/atko.tech/public_html/Alfraganus/resources/views/Admin/moliya/index.blade.php ENDPATH**/ ?>