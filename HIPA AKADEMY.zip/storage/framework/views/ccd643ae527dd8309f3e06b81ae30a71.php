<?php $__env->startSection('title','To\'lovlar'); ?>
<?php $__env->startSection('content'); ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>To'lovlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('Techer')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item active">To'lovlar</li>
                </ol>
            </nav>
        </div>
    
        <section class="section dashboard">
            <div class="card info-card sales-card">
                <div class="card-body text-center">
                    <h5 class="card-title">Ish haqi to'lovlari</span></h5>
                    <div class="table-responsive">
                        <table class="table text-center table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Guruh</th>
                                    <th>To'lov summasi</th>
                                    <th>To'lov turi</th>
                                    <th>To'lov haqida</th>
                                    <th>To'lov vaqti</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $Tulov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['guruh']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['about']); ?></td>
                                    <td><?php echo e($item['time']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=6 class="text-center">Ish haqi to'lovlar mavjud emas.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>  
        </section>

    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Techer.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u929278937/domains/atko.tech/public_html/Alfraganus/resources/views/Techer/pays.blade.php ENDPATH**/ ?>