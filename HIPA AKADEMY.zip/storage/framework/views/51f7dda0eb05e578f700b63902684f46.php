<?php $__env->startSection('title','SMS'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>SMS</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">SMS</li>
        </ol>
    </nav>
</div> 
    <section class="section dashboard">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php elseif(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
        <div class="row">
            <!--
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body text-center">
                        <h4 class="card-title mb-0 pb-0">Barcha talabalarga SMS yuborish</h4>
                        <form action="<?php echo e(route('sms_send')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="text"></label>
                            <textarea name="text" required class="form-control"></textarea>
                            <button class="w-100 btn btn-primary w-100 mt-2">SMS yuborish</button>
                        </form>
                    </div>
                </div>
            </div>
            -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body text-center">
                        <h4 class="card-title mb-0 pb-0">SMS statistika</h4>
                        <table class="table text-center">
                            <tr>
                                <th>Mavjud SMS</th>
                                <th>Yuborilgan SMS</th>
                            </tr>
                            <tr>
                                <td><?php echo e($SmsCounter['maxsms']); ?></td>
                                <td><?php echo e($SmsCounter['counte']); ?></td>
                            </tr>
                        </table>
                        <button class="w-100 btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#basicModal">Yuborilgan sms tarixi</button>
                        <div class="modal fade" id="basicModal" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">SMS tarixi</h5>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('sms_show')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <label for="start">dan</label>
                                                    <input type="date" required name="start" class="form-control">
                                                </div>
                                                <div class="col-lg-6">
                                                    <label for="end">gacha</label>
                                                    <input type="date" required name="end" class="form-control">
                                                </div>
                                            </div>
                                            <button class="btn btn-primary w-100 mt-2">SMS tarixi</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body text-center">
                        <h4 class="card-title">Bugun yuborilgan smslar</h4>
                        <table class="table table-bordered" style="font-size:12px;">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Telefon raqam</th>
                                    <th>SMS matni</th>
                                    <th>Yuborilgan vaqt</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $SendMessege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td style="font-size:12px;"><?php echo e($item['phone']); ?></td>
                                    <td style="text-align:left;font-size:12px;"><?php echo e($item['text']); ?></td>
                                    <td style="font-size:10px;"><?php echo e($item['created_at']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <div>
                <div>
            <div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views/SuperAdmin/sms/index.blade.php ENDPATH**/ ?>