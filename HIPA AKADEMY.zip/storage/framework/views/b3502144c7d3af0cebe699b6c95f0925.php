<?php $__env->startSection('title','Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

  <div class="pagetitle">
      <h1>Bosh sahifa</h1>
      <nav>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Bosh sahifa</li>
          </ol>
      </nav>
  </div>

    <?php if($Block=='true'): ?>
        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
            To'lov muddat yaqinlashmoqda. To'lovlarni o'z vaqtida amalga oshirishni unitmang!!!
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>


  <section class="section dashboard">
    <div class="row text-center">
      <div class="col-lg-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title pb-1 mb-1"><i class="bi bi-envelope-arrow-up"></i> Yuborilgan SMS</h5>
            <p class="mb-0 pb-0" style="font-size:25px;"><?php echo e($SmsCounter['counte']); ?></p>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title pb-1 mb-1"><i class="bi bi-envelope-check"></i> Mavjud SMSlar</h5>
            <p class="mb-0 pb-0" style="font-size:25px;"><?php echo e($SmsCounter['maxsms']); ?></p>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title pb-1 mb-1"><i class="bi bi-person"></i> Aktiv talabalar</h5>
            <p class="mb-0 pb-0" style="font-size:25px;"><?php echo e($ActivStudent); ?></p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-lg-6">
        <div class="card">
          <div class="card-body">
            <h1 class="card-title">Kunlik tashriflar</h1>
            <canvas id="kunlik_tashrif" style="max-height: 400px;"></canvas>
            <script>
              document.addEventListener("DOMContentLoaded", () => {
                new Chart(document.querySelector('#kunlik_tashrif'), {
                  type: 'radar',
                  data: {
                    labels: [
                      "<?php echo e($TashSMM['kunlik_tashrif']['0']['day_name']); ?>",
                      "<?php echo e($TashSMM['kunlik_tashrif']['1']['day_name']); ?>",
                      "<?php echo e($TashSMM['kunlik_tashrif']['2']['day_name']); ?>",
                      "<?php echo e($TashSMM['kunlik_tashrif']['3']['day_name']); ?>",
                      "<?php echo e($TashSMM['kunlik_tashrif']['4']['day_name']); ?>",
                      "<?php echo e($TashSMM['kunlik_tashrif']['5']['day_name']); ?>",
                      "<?php echo e($TashSMM['kunlik_tashrif']['6']['day_name']); ?>"
                    ],
                    datasets: [{
                      label: '',
                      data: [
                        <?php echo e($TashSMM['kunlik_tashrif']['0']['user_count']); ?>,
                        <?php echo e($TashSMM['kunlik_tashrif']['1']['user_count']); ?>,
                        <?php echo e($TashSMM['kunlik_tashrif']['2']['user_count']); ?>,
                        <?php echo e($TashSMM['kunlik_tashrif']['3']['user_count']); ?>,
                        <?php echo e($TashSMM['kunlik_tashrif']['4']['user_count']); ?>,
                        <?php echo e($TashSMM['kunlik_tashrif']['5']['user_count']); ?>,
                        <?php echo e($TashSMM['kunlik_tashrif']['6']['user_count']); ?>

                      ],
                      fill: true,
                      backgroundColor: 'rgba(54, 162, 235, 0.2)',
                      borderColor: 'rgb(54, 162, 235)',
                      pointBackgroundColor: 'rgb(54, 162, 235)',
                      pointBorderColor: '#fff',
                      pointHoverBackgroundColor: '#fff',
                      pointHoverBorderColor: 'rgb(54, 162, 235)'
                    }]
                  },
                  options: {elements: {line: {borderWidth: 3}}}
                });
              });
            </script>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card">
          <div class="card-body">
            <h1 class="card-title">Tashriflar(oxirgi 7kun)</h1>
            <canvas id="crm_tashrif" style="max-height: 400px;"></canvas>
            <script> 
              document.addEventListener("DOMContentLoaded", () => {
                new Chart(document.querySelector('#crm_tashrif'), {
                  type: 'radar',
                  data: {
                    labels: ['Telegram','Instagram','Facebook','Bannerlar','Tanishlar','Boshqa'],
                    datasets: [{
                      label: '',
                      data: [
                        "<?php echo e($TashSMM['smm']['Telegram']); ?>",
                        "<?php echo e($TashSMM['smm']['Instagram']); ?>",
                        "<?php echo e($TashSMM['smm']['Facebook']); ?>",
                        "<?php echo e($TashSMM['smm']['Banner']); ?>",
                        "<?php echo e($TashSMM['smm']['Tanishlar']); ?>",
                        "<?php echo e($TashSMM['smm']['Boshqalar']); ?>"
                      ],
                      fill: true,
                      backgroundColor: 'rgba(255, 65, 65, 0.4)',
                      borderColor: 'rgb(52, 205, 244)',
                      pointBackgroundColor: 'rgb(54, 205, 244)',
                      pointBorderColor: '#fff',
                      pointHoverBackgroundColor: '#fff',
                      pointHoverBorderColor: 'rgb(54, 205, 235)'
                    }]
                  },
                  options: {elements: {line: {borderWidth: 3}}}
                });
              });
            </script>
          </div>
        </div>
      </div>
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <h1 class="card-title">Kunlik to'lovlar</h1>
            <div id="columnChart"></div>
            <script>
              document.addEventListener("DOMContentLoaded", () => {
                new ApexCharts(document.querySelector("#columnChart"), {
                  series: [{
                    name: "Naqt to'lovlar",
                    data: [
                      <?php echo e($Tulov[0]['Naqt']); ?>,
                      <?php echo e($Tulov[1]['Naqt']); ?>,
                      <?php echo e($Tulov[2]['Naqt']); ?>,
                      <?php echo e($Tulov[3]['Naqt']); ?>,
                      <?php echo e($Tulov[4]['Naqt']); ?>,
                      <?php echo e($Tulov[5]['Naqt']); ?>,
                      <?php echo e($Tulov[6]['Naqt']); ?>

                    ]
                  }, {
                    name: "Plastik to'lovlar",
                    data: [
                      <?php echo e($Tulov[0]['Plastik']); ?>,
                      <?php echo e($Tulov[1]['Plastik']); ?>,
                      <?php echo e($Tulov[2]['Plastik']); ?>,
                      <?php echo e($Tulov[3]['Plastik']); ?>,
                      <?php echo e($Tulov[4]['Plastik']); ?>,
                      <?php echo e($Tulov[5]['Plastik']); ?>,
                      <?php echo e($Tulov[6]['Plastik']); ?>

                    ]
                  }, {
                    name: "Payme to'lov",
                    data: [
                      <?php echo e($Tulov[0]['Payme']); ?>,
                      <?php echo e($Tulov[1]['Payme']); ?>,
                      <?php echo e($Tulov[2]['Payme']); ?>,
                      <?php echo e($Tulov[3]['Payme']); ?>,
                      <?php echo e($Tulov[4]['Payme']); ?>,
                      <?php echo e($Tulov[5]['Payme']); ?>,
                      <?php echo e($Tulov[6]['Payme']); ?>

                    ]
                  }, {
                    name: "Qaytarilgan to'lovlar",
                    data: [
                      <?php echo e($Tulov[0]['Qaytarildi']); ?>,
                      <?php echo e($Tulov[1]['Qaytarildi']); ?>,
                      <?php echo e($Tulov[2]['Qaytarildi']); ?>,
                      <?php echo e($Tulov[3]['Qaytarildi']); ?>,
                      <?php echo e($Tulov[4]['Qaytarildi']); ?>,
                      <?php echo e($Tulov[5]['Qaytarildi']); ?>,
                      <?php echo e($Tulov[6]['Qaytarildi']); ?>

                    ]
                  }, {
                    name: "Chegirmalar",
                    data: [
                      <?php echo e($Tulov[0]['Chegirma']); ?>,
                      <?php echo e($Tulov[1]['Chegirma']); ?>,
                      <?php echo e($Tulov[2]['Chegirma']); ?>,
                      <?php echo e($Tulov[3]['Chegirma']); ?>,
                      <?php echo e($Tulov[4]['Chegirma']); ?>,
                      <?php echo e($Tulov[5]['Chegirma']); ?>,
                      <?php echo e($Tulov[6]['Chegirma']); ?>

                    ]
                  }],
                  chart: {type: 'bar',height: 350},
                  plotOptions: {
                    bar: {horizontal: false,columnWidth: '55%',endingShape: 'rounded'},
                  },
                  dataLabels: {enabled: false},
                  stroke: {show: true,width: 2,colors: ['transparent']},
                  xaxis: {
                    categories: [
                      "<?php echo e($Tulov[0]['date_wekend']); ?>",
                      "<?php echo e($Tulov[1]['date_wekend']); ?>",
                      "<?php echo e($Tulov[2]['date_wekend']); ?>",
                      "<?php echo e($Tulov[3]['date_wekend']); ?>",
                      "<?php echo e($Tulov[4]['date_wekend']); ?>",
                      "<?php echo e($Tulov[5]['date_wekend']); ?>",
                      "<?php echo e($Tulov[6]['date_wekend']); ?>"
                    ],
                  },
                  yaxis: {title: {text: "Kunlik to'lovlar"}},
                  fill: {opacity: 1},
                  tooltip: {y: {formatter: function(val) {return val + " so'm"}}}
                }).render();
              });
            </script>
            <div class="table-responsive">
              <table class="table table-bordered text-center table-striped table-hover" style="font-size:14px;">
                <thead>
                  <tr>
                    <th>#/#</th>
                    <th><a href="<?php echo e(route('tulovShowSuperAdmin',$Tulov[0]['date'])); ?>"><?php echo e($Tulov[0]['date_wekend']); ?></a></th>
                    <th><a href="<?php echo e(route('tulovShowSuperAdmin',$Tulov[1]['date'])); ?>"><?php echo e($Tulov[1]['date_wekend']); ?></a></th>
                    <th><a href="<?php echo e(route('tulovShowSuperAdmin',$Tulov[2]['date'])); ?>"><?php echo e($Tulov[2]['date_wekend']); ?></a></th>
                    <th><a href="<?php echo e(route('tulovShowSuperAdmin',$Tulov[3]['date'])); ?>"><?php echo e($Tulov[3]['date_wekend']); ?></a></th>
                    <th><a href="<?php echo e(route('tulovShowSuperAdmin',$Tulov[4]['date'])); ?>"><?php echo e($Tulov[4]['date_wekend']); ?></a></th>
                    <th><a href="<?php echo e(route('tulovShowSuperAdmin',$Tulov[5]['date'])); ?>"><?php echo e($Tulov[5]['date_wekend']); ?></a></th>
                    <th><a href="<?php echo e(route('tulovShowSuperAdmin',$Tulov[6]['date'])); ?>"><?php echo e($Tulov[6]['date_wekend']); ?></a></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th style="text-align:left;">Naqt To'lovlar</th>
                    <td><?php echo e($Tulov[0]['Table_Naqt']); ?></td>
                    <td><?php echo e($Tulov[1]['Table_Naqt']); ?></td>
                    <td><?php echo e($Tulov[2]['Table_Naqt']); ?></td>
                    <td><?php echo e($Tulov[3]['Table_Naqt']); ?></td>
                    <td><?php echo e($Tulov[4]['Table_Naqt']); ?></td>
                    <td><?php echo e($Tulov[5]['Table_Naqt']); ?></td>
                    <td><?php echo e($Tulov[6]['Table_Naqt']); ?></td>
                  </tr>
                  <tr>
                    <th style="text-align:left;">Plastik To'lovlar</th>
                    <td><?php echo e($Tulov[0]['Table_Plastik']); ?></td>
                    <td><?php echo e($Tulov[1]['Table_Plastik']); ?></td>
                    <td><?php echo e($Tulov[2]['Table_Plastik']); ?></td>
                    <td><?php echo e($Tulov[3]['Table_Plastik']); ?></td>
                    <td><?php echo e($Tulov[4]['Table_Plastik']); ?></td>
                    <td><?php echo e($Tulov[5]['Table_Plastik']); ?></td>
                    <td><?php echo e($Tulov[6]['Table_Plastik']); ?></td>
                  </tr>
                  <tr>
                    <th style="text-align:left;">Payme to'lov</th>
                    <td><?php echo e($Tulov[0]['Table_Payme']); ?></td>
                    <td><?php echo e($Tulov[1]['Table_Payme']); ?></td>
                    <td><?php echo e($Tulov[2]['Table_Payme']); ?></td>
                    <td><?php echo e($Tulov[3]['Table_Payme']); ?></td>
                    <td><?php echo e($Tulov[4]['Table_Payme']); ?></td>
                    <td><?php echo e($Tulov[5]['Table_Payme']); ?></td>
                    <td><?php echo e($Tulov[6]['Table_Payme']); ?></td>
                  </tr>
                  <tr>
                    <th style="text-align:left;">Chegirma To'lovlar</th>
                    <td><?php echo e($Tulov[0]['Table_Chegirma']); ?></td>
                    <td><?php echo e($Tulov[1]['Table_Chegirma']); ?></td>
                    <td><?php echo e($Tulov[2]['Table_Chegirma']); ?></td>
                    <td><?php echo e($Tulov[3]['Table_Chegirma']); ?></td>
                    <td><?php echo e($Tulov[4]['Table_Chegirma']); ?></td>
                    <td><?php echo e($Tulov[5]['Table_Chegirma']); ?></td>
                    <td><?php echo e($Tulov[6]['Table_Chegirma']); ?></td>
                  </tr>
                  <tr>
                    <th style="text-align:left;">Qaytarilgan To'lovlar</th>
                    <td><?php echo e($Tulov[0]['Table_Qaytarildi']); ?></td>
                    <td><?php echo e($Tulov[1]['Table_Qaytarildi']); ?></td>
                    <td><?php echo e($Tulov[2]['Table_Qaytarildi']); ?></td>
                    <td><?php echo e($Tulov[3]['Table_Qaytarildi']); ?></td>
                    <td><?php echo e($Tulov[4]['Table_Qaytarildi']); ?></td>
                    <td><?php echo e($Tulov[5]['Table_Qaytarildi']); ?></td>
                    <td><?php echo e($Tulov[6]['Table_Qaytarildi']); ?></td>
                  </tr>
                  <tr>
                    <th style="text-align:left;">Naqt + Plastik + Payme</th>
                    <td><?php echo e($Tulov[0]['Table_Naqt_Plastik_Payme']); ?></td>
                    <td><?php echo e($Tulov[1]['Table_Naqt_Plastik_Payme']); ?></td>
                    <td><?php echo e($Tulov[2]['Table_Naqt_Plastik_Payme']); ?></td>
                    <td><?php echo e($Tulov[3]['Table_Naqt_Plastik_Payme']); ?></td>
                    <td><?php echo e($Tulov[4]['Table_Naqt_Plastik_Payme']); ?></td>
                    <td><?php echo e($Tulov[5]['Table_Naqt_Plastik_Payme']); ?></td>
                    <td><?php echo e($Tulov[6]['Table_Naqt_Plastik_Payme']); ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>  
    
    <div class="card">
        <div class="card-body text-center pt-4">
            <div class="table-responsive">
                <table class="table table-bordered" style="font-size:14px;">
                    <thead class="">
                      <tr>
                        <th rowspan=2 class="align-middle"><i class="bi bi-house-door-fill"></i> Filial</th>
                        <th rowspan=2 class="align-middle"><i class="bi bi-people"></i> Tashriflar</th>
                        <th colspan=4 class=""><i class="bi bi-menu-button-wide"></i> Guruhlar</th>
                        <th colspan=2 class=""><i class="bi bi-microsoft-teams"></i> Hodimlar</th>
                      </tr>
                      <tr>
                        <th style="font-size:10px;">Jami</th>
                        <th style="font-size:10px;">Yangi</th>
                        <th style="font-size:10px;">Aktiv</th>
                        <th style="font-size:10px;">Yakunlangan</th>
                        <th style="font-size:10px;">O'qituvchilar</th>
                        <th style="font-size:10px;">Menegerlar</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $Filial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th style="font-weight:900" class="text-primary"><?php echo e($item['filial_name']); ?></th>
                            <td><?php echo e($item['user']); ?></td>
                            <td><?php echo e($item['guruhlar']); ?></td>
                            <td><?php echo e($item['yangiguruh']); ?></td>
                            <td><?php echo e($item['aktivguruh']); ?></td>
                            <td><?php echo e($item['endguruh']); ?></td>
                            <td><?php echo e($item['techer']); ?></td>
                            <td><?php echo e($item['meneger']); ?></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>


</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views/SuperAdmin/index.blade.php ENDPATH**/ ?>