<?php $__env->startSection('title',"O'qituvchiga to'lovlar"); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>O'qituvchiga to'lovlar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">O'qituvchiga to'lovlar</li>
        </ol>
    </nav>
</div> 
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
    <section class="section dashboard">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title w-100 text-center mb-1 pb-1">O'qituvchiga to'lovlar</h5>
                <p class="text-danger p-0 m-0 w-100 text-center">O'qituvchi guruhlari yakunlangadan 30 kundan kiyin avtoamatik o'chiriladi.</p>
                <div class="table-responsive">
                    <table class="table text-center table-bordered" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th class="bg-primary text-white">#</th>
                                <th class="bg-primary text-white">Filial</th>
                                <th class="bg-primary text-white">Guruh</th>
                                <th class="bg-primary text-white">O'qituvchi</th>
                                <th class="bg-primary text-white">Hisoblangan</th>
                                <th class="bg-primary text-white">To'langan</th>
                                <th class="bg-primary text-white">Qoldiq</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $Report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($item['filial_name']); ?></td>
                                <td><?php echo e($item['guruh_name']); ?></td>
                                <td><?php echo e($item['techer']); ?></td>
                                <td><?php echo e($item['hisoblash2']); ?></td>
                                <td><?php echo e($item['tulov2']); ?></td>
                                <td>
                                    <?php if($item['qoldiq']>=0): ?>
                                        <?php echo e($item['qoldiq2']); ?>

                                    <?php else: ?>
                                        <b class="text-danger"><?php echo e($item['qoldiq2']); ?></b>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan=7 class="text-center">Guruhlar mavjud emas.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>  
        
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u929278937/domains/atko.tech/public_html/Alfraganus/resources/views/SuperAdmin/techer/index.blade.php ENDPATH**/ ?>