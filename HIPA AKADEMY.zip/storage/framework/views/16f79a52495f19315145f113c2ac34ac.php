<?php $__env->startSection('title','Filiallar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Filiallar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Filiallar</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<section class="section dashboard">
  <div class="card info-card sales-card">
    <div class="card-body text-center">
      <div class="row">
        <div class="col-6"><h5 class="card-title">Filiallar</span></h5></div>
        <div class="col-6"><button class="btn btn-success text-white w-100 mt-3" data-bs-toggle="modal" data-bs-target="#yangi_filial"> <i class="bi bi-patch-plus"></i> Yangi Filial</button></div>

        <div class="modal fade" id="yangi_filial" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title w-100 text-center">Yangi filial qo'shish</h5>
              </div>
              <div class="modal-body">
                  <form action="<?php echo e(route('filialcreate')); ?>" method="post"><?php echo csrf_field(); ?>
                    <label for="filial_name" class="mt-lg-0 mt-2">Filial nomi</label>
                    <input type="text" name="filial_name" class="form-control" required>
                    <label for="filial_addres" class="mt-lg-0 mt-2">Filial manzili</label>
                    <input type="text" name="filial_addres" class="form-control" required>
                    <div class="row">
                      <div class="col-6">
                        <button type="button" class="btn btn-secondary w-100 mt-3" data-bs-dismiss="modal">Bekor Qilish</button>
                      </div>
                      <div class="col-6">
                        <button type="submit" class="btn btn-primary w-100 mt-3">Filialni saqlash</button>
                      </div>
                    </div>
                  </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="table-responsive">
        <table class="table table-bordered text-center table-striped table-hover" style="font-size:14px;">
          <thead>
            <tr>
              <th class="bg-primary text-white">#</th>
              <th class="bg-primary text-white">Filial</th>
              <th class="bg-primary text-white">Naqt</th>
              <th class="bg-primary text-white">Plastik</th>
              <th class="bg-primary text-white">Payme</th>
              <th class="bg-primary text-white">Ish haqi Naqt</th>
              <th class="bg-primary text-white">Ish haqi Plastik</th>
              <th class="bg-primary text-white">Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $Filial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($loop->index+1); ?></td>
              <td style="text-align:left;">
                <b><a href="<?php echo e(route('filailCrm',$item['id'])); ?>"><i class="bi bi-door-open"></i> <?php echo e($item['filial_name']); ?></a></b>
              </td>
              <td><?php echo e($item['naqt']); ?></td>
              <td><?php echo e($item['plastik']); ?></td>
              <td><?php echo e($item['payme']); ?></td>
              <td><?php echo e($item['IshHaqiNaqt']); ?></td>
              <td><?php echo e($item['IshHaqiPlastik']); ?></td>
              <td style="text-align:right">
                <a href="<?php echo e(route('SuperAdminStatistika' , $item['id'])); ?>" title="Statistika" class="btn btn-danger py-0 my-1 my-lg-0"><i class="bi bi-bar-chart"></i></a>
                <a href="<?php echo e(route('filial.show',$item['id'] )); ?>" title="Filial sozlamalari" 
                class="btn btn-primary py-0 my-1 my-lg-0"><i class="bi bi-gear"></i></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan=8 class="text-center">Filiallar mavjud emas</td>
            </tr>
            <?php endif; ?>
            <tr>
              <th colspan=2>Jami:</th>
              <th><?php echo e($Naqt); ?></th>
              <th><?php echo e($Plastik); ?></th>
              <th><?php echo e($Payme); ?></th>
              <th></th>
              <th colspan=3 style="text-align:right">Muumiy balans: <?php echo e($Jami); ?></th>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="row">
        <div class="col-lg-2"></div>
        <div class="col-lg-4">
          <button class="btn btn-outline-warning text-primary w-100 mt-2 mt-lg-0" data-bs-toggle="modal" data-bs-target="#filial_qaytar"><i class="bi bi-coin"></i> Filialga ish haqini qaytarish</button></div>
        <div class="col-lg-4">
          <button class="btn btn-outline-danger text-primary w-100 mt-2 mt-lg-0" data-bs-toggle="modal" data-bs-target="#umumitxarajat"><i class="bi bi-cart2"></i> Xarajatlar uchun chiqim</button></div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="filial_qaytar" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Filialga ish haqi uchun aytarish</h5>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('SuperAdminMoliyaKassaga')); ?>" id="form1" method="post"><?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-12">
                <label for="filial_id">Filial balansini tanlang</label>
                <select name="filial_id" class="form-select my-1" required>
                  <option value="">Tanlang...</option>
                  <?php $__currentLoopData = $Filial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item['id']); ?>"><?php echo e($item['filial_name']); ?> Mavjud:(Naqt: <?php echo e($item['naqt']); ?>) (Plastik: <?php echo e($item['plastik']); ?>)(Payme: <?php echo e($item['payme']); ?>)</option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="filial_id2">Qaytariladigan filialni tanlang</label>
                <select name="filial_id2" class="form-select my-1 mb-2" required>
                  <option value="">Tanlang...</option>
                  <?php $__currentLoopData = $Filial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item['id']); ?>"><?php echo e($item['filial_name']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="summa">Qaytariladigan summa</label>
                <input type="text" name="summa" id="summa1" class="form-control my-1" required>
                <label for="type">To'lov turi</label>
                <select name="type" class="form-select my-1" required>
                  <option value="">Tanlang...</option>
                  <option value="Naqt">Naqt</option>
                  <option value="Plastik">Plastik</option>
                </select>
                <label for="about">Qaytarish haqida</label>
                <textarea name="about" class="form-control my-1 mb-2" required></textarea>
              </div>
              <div class="col-6">
                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Bekor qilish</button>
              </div>
              <div class="col-6">
                <button type="submit" class="btn btn-primary w-100">Saqlash</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="umumitxarajat" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Umumiy xarajatlar uchun Chiqim qilish</h5>
        </div>
        <div class="modal-body">
        <form action="<?php echo e(route('SuperAdminMoliyaXarajay')); ?>" id="form2" method="post"><?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-12">
                <label for="filial_id">Filialni tanlang</label>
                <select name="filial_id" id="" class="form-select my-1" required>
                  <option value="">Tanlang...</option>
                  <?php $__currentLoopData = $Filial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item['id']); ?>"><?php echo e($item['filial_name']); ?> Mavjud:(Naqt: <?php echo e($item['naqt']); ?>) (Plastik: <?php echo e($item['plastik']); ?>)(Payme: <?php echo e($item['payme']); ?>)</option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="summa">Xarajat summasi</label>
                <input type="text" name="summa" id="summa1" class="form-control my-1" required>
                <label for="type">To'lov turi</label>
                <select name="type" id="" class="form-select my-1" required>
                  <option value="">Tanlang...</option>
                  <option value="Naqt">Naqt</option>
                  <option value="Plastik">Plastik</option>
                  <option value="Payme">Payme </option>
                </select>
                <label for="about">Xarajat haqida</label>
                <textarea name="about" class="form-control my-1 mb-2" required></textarea>
              </div>
              <div class="col-6">
                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Bekor qilish</button>
              </div>
              <div class="col-6">
                <button type="submit" class="btn btn-primary w-100">Saqlash</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="card info-card sales-card">
    <div class="card-body text-center">
      <h5 class="card-title mb-0 pb-2"><i class="bi bi-cart2"></i> Umumiy balans tarixi (oxirgi 30 kunlik)</span></h5>
      <div class="table-responsive">
        <table class="table table-bordered" style="font-size:14px">
          <thead>
            <tr>
              <td class="bg-primary text-white">#</td>
              <td class="bg-primary text-white">Filial</td>
              <td class="bg-primary text-white">Status</td>
              <td class="bg-primary text-white">Summa</td>
              <td class="bg-primary text-white">Type</td>
              <td class="bg-primary text-white">Xarajat xaqida</td>
              <td class="bg-primary text-white">Xarajat vaqti</td>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $Xarajatlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($loop->index+1); ?></td>
                <td style="text-align:left"><?php echo e($item['filial_name']); ?></td>
                <td style="text-align:left">
                  <?php if($item['xodisa']=='Chiqim'): ?>
                    Filial kassasidan kirim.
                  <?php elseif($item['xodisa']=='Qaytarildi'): ?>
                    Ish haqi uchun kassaga qaytarildi.
                  <?php elseif($item['xodisa']=='XarajatAdmin'): ?>
                    Xarajat uchun chiqim qilindi.
                  <?php endif; ?>
                </td>
                <td><?php echo e($item['summa']); ?></td>
                <td><?php echo e($item['type']); ?></td>
                <td><?php echo e($item['about']); ?></td>
                <td style="text-align:right"><?php echo e($item['created_at']); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan=6 class="text-center">Xarajatlar mavjud emas.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
     
</section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HIPA AKADEMY\resources\views/SuperAdmin/filial.blade.php ENDPATH**/ ?>